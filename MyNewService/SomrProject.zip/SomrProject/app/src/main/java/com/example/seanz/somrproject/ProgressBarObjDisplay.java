package com.example.seanz.somrproject;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

/**
 * Created by seanz on 19-Jun-18.
 */

public class ProgressBarObjDisplay {

    private ProgressBarObj progressBar;
    private NotificationCompat.Builder builder;
    private NotificationManager manager;

    public ProgressBarObjDisplay(ProgressBarObj pbo, Context context) {
        this.progressBar = pbo;
        NotificationChannel progressChannel = new NotificationChannel("progressId", "Progress", NotificationManager.IMPORTANCE_DEFAULT);
        builder = new NotificationCompat.Builder(context, "transfer")
                .setSmallIcon(R.drawable.icon_information)
                .setContentTitle("Transferring Photos")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setChannelId("progressId")
                .setContentText("Transferring");

        // Add as notification
        manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.createNotificationChannel(progressChannel);
    }

    public void setMaxVal(int maxVal) {
        this.progressBar.setMaxVal(maxVal);
    }

    public void incrementCount() {
        this.progressBar.incrCurrVal();
        builder.setProgress(progressBar.getMaxVal(), progressBar.getCurrVal(), false);
        builder.setContentText(progressBar.getCurrVal() + "/" + progressBar.getMaxVal() + " Transferred ");
        manager.notify(0, builder.build());
    }

    public void startNewCount() {
        builder.setProgress(0, 0, false);
        builder.setContentText("Starting Transfer");
        manager.notify(0, builder.build());
    }

    public void finishCount() {
        builder.setProgress(0, 0, false);
        builder.setContentText("Finished");
        manager.notify(0, builder.build());
    }

}
