package com.example.seanz.somrproject;


/**
 * Created by seanz on 19-Jun-18.
 */

public class ProgressBarObj {

    private int maxVal;
    private int currVal;

    public ProgressBarObj() {
        this.maxVal = 0;
        this.currVal = 0;
    }

    public int getMaxVal() {
        return this.maxVal;
    }

    public int getCurrVal() {
        return this.currVal;
    }

    public void setMaxVal(int val) {
        this.maxVal = val;
    }

    public void incrCurrVal() {
        this.currVal++;
    }

    public void reset() {
        this.currVal = 0;
    }
}
