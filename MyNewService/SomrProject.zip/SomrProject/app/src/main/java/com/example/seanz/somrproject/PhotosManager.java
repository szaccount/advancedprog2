package com.example.seanz.somrproject;

import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FilenameFilter;

/**
 * Created by seanz on 19-Jun-18.
 */

public class PhotosManager {

    public File[] GetPhotos() {
        File dcim = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM + "/Camera");
        if (dcim == null) {
            return null;
        }

        File[] photosTmp = dcim.listFiles();
        File[] photos = dcim.listFiles(new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return (name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".png") ||
                        name.endsWith(".bmp") || name.endsWith(".gif"));
            }
        });

        return photos;
    }
}
